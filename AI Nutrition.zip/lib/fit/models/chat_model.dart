class ChatModel {
  final String name;
  final String image;
  final String lastMessage;
  ChatModel(
      {required this.image, required this.lastMessage, required this.name});
}
