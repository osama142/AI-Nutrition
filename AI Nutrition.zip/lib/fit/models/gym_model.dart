class GymModel {
  final String name;
  final String image;
  GymModel({required this.image, required this.name});
}
