// TODO Implement this library.
import 'package:flutter/material.dart';

const kFirstColor = Color(0xFF40D876);
const kSecondColor = Color(0xFF232441);
const kThirdColor = Color(0xFF131429);
