class DietModel{

  String? image;
  String? title;
  String? subTitle;
}