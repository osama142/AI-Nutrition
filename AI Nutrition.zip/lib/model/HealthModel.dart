class HealthModel{

  String? image,title,desc,time;
  bool? isFav=false;
}