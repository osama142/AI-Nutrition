class FoodModel{


  String? image;
  String? title;
  String? desc="Food is any substance consumed to provide nutritional support for an organism.";
  String? time="10 min";
  String? kCal="234 kCal";
}