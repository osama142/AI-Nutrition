class CategoryModel{


  String? image;
  String? title;
}