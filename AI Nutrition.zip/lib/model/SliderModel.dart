class SliderModel{


  String? image;
  String? title;
}