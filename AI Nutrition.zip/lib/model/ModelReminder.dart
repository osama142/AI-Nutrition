
class ModelReminder {
  int? id;
  String? time;
  String? repeat;
  bool? ison=false;



}
