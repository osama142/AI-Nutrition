
class IntroModel{

  int? id;


  String? image;
  String? name;
  String? desc;


}