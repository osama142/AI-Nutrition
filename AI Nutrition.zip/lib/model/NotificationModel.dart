
class NotificationModel{




  String? time;
  String? title;
  String? desc;


}