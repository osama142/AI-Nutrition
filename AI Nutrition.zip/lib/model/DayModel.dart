class DayModel{
  String? name;
  String? image;
}