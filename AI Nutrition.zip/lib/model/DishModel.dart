class DishModel{
  String? image;
  String? desc;
  String? title;
}